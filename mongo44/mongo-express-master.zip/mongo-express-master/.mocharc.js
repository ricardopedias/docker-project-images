'use strict';

module.exports = {
  recursive: true,
  reporter: 'dot',
  exit: true,
};
